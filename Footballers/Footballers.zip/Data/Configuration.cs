﻿namespace Footballers.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-0ADTPNC\SQLEXPRESS;Database=FootballersExam123;Trusted_Connection=True";
    }
}
