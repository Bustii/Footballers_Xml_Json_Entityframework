﻿namespace Footballers.Data.Models.Enums
{
    public enum PositionType
    {
        Goalkeeper = 0, 
        Defender = 1, 
        Midfielder = 2, 
        Forward = 3,
    }
}
